using UnityEditorInternal;
using UnityEngine;

public class GameManager : MonoBehaviour
{
    //singleton pattern 
    private static GameManager instance = null;
    private void Awake()
    {
        if (instance != null)
        {
            Destroy(gameObject);
            return;
        }

        DontDestroyOnLoad(gameObject);
        instance = GetComponent<GameManager>();
    }

    public static GameManager GetInstance()
    {
        return instance;
    }
}
